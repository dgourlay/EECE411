Name: Derek Gourlay
studentID: 66435041
Secret Code: CBFA8D62209A392FE67BEC8A54DB47A5FA1E750E

========================
HOW TO RUN
========================

To run the project from the command line and type the following:

java -jar A1.jar serverAddr (portNumber) studentNum

Note:
* Replace "serverAddr" with the address of the Assignment01 Server (ex. reala.ece.ubc.ca)
* portNumber is optional, replace it with the desired port otherwise it defaults to 5627
* Replace "studentNum" with the desired student number (ex. 909090)
